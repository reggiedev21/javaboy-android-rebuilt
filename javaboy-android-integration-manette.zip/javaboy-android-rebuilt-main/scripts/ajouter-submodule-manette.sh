#!/usr/bin/env bash
# Ajoute le dépôt Manette en submodule git, à l'emplacement attendu par android/settings.gradle.kts.
# À lancer une seule fois, puis committer .gitmodules et third_party/Manette.
#
#   scripts/ajouter-submodule-manette.sh <URL du dépôt Manette> [branche]
set -euo pipefail

url=${1:?"usage : $0 <URL du dépôt Manette> [branche, défaut : master]"}
branch=${2:-master}
dest=third_party/Manette

cd "$(git rev-parse --show-toplevel)"
if [ -e "$dest" ]; then
    echo "$dest existe déjà : rien à faire (git submodule update --init pour le remplir)." >&2
    exit 1
fi

git submodule add -b "$branch" "$url" "$dest"
echo
echo "Submodule ajouté sur la branche '$branch'. Reste à faire :"
echo "  git commit -m \"Ajout du submodule Manette\""
echo "Après un clone : git clone --recurse-submodules …  ou  git submodule update --init"
echo "Mettre à jour  : git submodule update --remote $dest   puis committer"

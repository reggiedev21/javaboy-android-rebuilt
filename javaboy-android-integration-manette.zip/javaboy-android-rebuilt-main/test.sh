#!/bin/sh
# Tests hors-ligne : compile core + shim JUnit + tests, puis exécute MiniRunner.
set -e
JAVAC=${JAVAC:-javac}
OUT=build/test-classes; rm -rf $OUT; mkdir -p $OUT
"$JAVAC" -encoding UTF-8 -nowarn -d $OUT $(find core/src/main/java tools/junit-shim core/src/test/java -name '*.java')
java -cp $OUT MiniRunner javaboy.core.AluTest javaboy.core.CartridgeTest javaboy.core.CpuTest javaboy.core.CpuTableTest javaboy.core.GraphicsChipTest javaboy.core.PngExportTest javaboy.core.SaveStateTest javaboy.core.FiltersTest javaboy.core.RomArchiveTest javaboy.core.BlarggTest javaboy.core.RomSmokeTest javaboy.core.ThreadingTest javaboy.core.MapperTest javaboy.core.RtcTest "$@"
